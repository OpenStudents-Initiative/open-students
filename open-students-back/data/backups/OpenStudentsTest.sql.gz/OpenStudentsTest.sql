--
-- PostgreSQL database dump
--

-- Dumped from database version 14.9 (Homebrew)
-- Dumped by pg_dump version 14.9 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: academic_period; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.academic_period (
    name character varying NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


ALTER TABLE public.academic_period OWNER TO postgres;

--
-- Name: academic_period_course; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.academic_period_course (
    fk_academic_period uuid NOT NULL,
    fk_course uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


ALTER TABLE public.academic_period_course OWNER TO postgres;

--
-- Name: course; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.course (
    name character varying NOT NULL,
    number smallint,
    fk_dependency uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


ALTER TABLE public.course OWNER TO postgres;

--
-- Name: dependency; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dependency (
    name character varying NOT NULL,
    abbreviation character varying,
    fk_university uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


ALTER TABLE public.dependency OWNER TO postgres;

--
-- Name: professor; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.professor (
    name character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


ALTER TABLE public.professor OWNER TO postgres;

--
-- Name: professor_dependency; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.professor_dependency (
    fk_professor uuid NOT NULL,
    fk_dependency uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


ALTER TABLE public.professor_dependency OWNER TO postgres;

--
-- Name: review; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.review (
    review character varying NOT NULL,
    general_rating numeric NOT NULL,
    difficulty_level numeric NOT NULL,
    course_grade numeric NOT NULL,
    would_enroll_again boolean NOT NULL,
    fk_professor uuid NOT NULL,
    fk_course uuid NOT NULL,
    fk_academic_period uuid NOT NULL,
    fk_creator uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


ALTER TABLE public.review OWNER TO postgres;

--
-- Name: student; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.student (
    name character varying NOT NULL,
    nickname character varying,
    email character varying NOT NULL,
    password character varying NOT NULL,
    fk_university uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


ALTER TABLE public.student OWNER TO postgres;

--
-- Name: university; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.university (
    name character varying NOT NULL,
    nickname character varying,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


ALTER TABLE public.university OWNER TO postgres;

--
-- Data for Name: academic_period; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.academic_period (name, start_date, end_date, created_at, id) FROM stdin;
202410	2024-01-01	2024-06-01	2024-03-03 15:22:58.03805-05	5d8e959d-1bf0-484b-89fc-11370407a210
\.


--
-- Data for Name: academic_period_course; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.academic_period_course (fk_academic_period, fk_course, created_at, id) FROM stdin;
5d8e959d-1bf0-484b-89fc-11370407a210	06ef6ca5-3bc3-4a06-8706-f181ad96ea14	2024-03-03 15:23:21.159795-05	d6ac9289-616e-478e-bc6d-c9d6d18ffca9
5d8e959d-1bf0-484b-89fc-11370407a210	fe8d6bf8-42c4-41f5-9530-a7aa51a65714	2024-03-03 15:23:55.670308-05	57d8bc26-f8df-494a-bc64-77c2af09efbd
\.


--
-- Data for Name: course; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.course (name, number, fk_dependency, created_at, id) FROM stdin;
Introducción a la Programación	1221	df9d9c47-45f5-4e70-b179-ae5916475f21	2024-03-03 15:23:21.159795-05	06ef6ca5-3bc3-4a06-8706-f181ad96ea14
Estructuras de Datos y Algoritmos	1225	df9d9c47-45f5-4e70-b179-ae5916475f21	2024-03-03 15:23:55.670308-05	fe8d6bf8-42c4-41f5-9530-a7aa51a65714
\.


--
-- Data for Name: dependency; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dependency (name, abbreviation, fk_university, created_at, id) FROM stdin;
Ingeniería de Sistemas y Computación	ISIS	0c79eea7-b529-4881-8532-128081bf2a50	2024-03-03 15:22:44.138629-05	df9d9c47-45f5-4e70-b179-ae5916475f21
\.


--
-- Data for Name: professor; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.professor (name, created_at, id) FROM stdin;
Chrisitan Aparicio	2024-03-03 15:24:11.688148-05	7ec2330e-7269-49d3-9075-c0d5bd1fde43
Marcela Hernández	2024-03-03 15:24:31.373878-05	e22c3fea-3a32-4b49-98fc-9047026f1e10
\.


--
-- Data for Name: professor_dependency; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.professor_dependency (fk_professor, fk_dependency, created_at, id) FROM stdin;
7ec2330e-7269-49d3-9075-c0d5bd1fde43	df9d9c47-45f5-4e70-b179-ae5916475f21	2024-03-03 15:24:11.688148-05	28c33be2-8d24-414c-a34f-bee3b4fa636f
e22c3fea-3a32-4b49-98fc-9047026f1e10	df9d9c47-45f5-4e70-b179-ae5916475f21	2024-03-03 15:24:31.373878-05	5d920a86-c837-4743-bda5-4a1da1c7d813
\.


--
-- Data for Name: review; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.review (review, general_rating, difficulty_level, course_grade, would_enroll_again, fk_professor, fk_course, fk_academic_period, fk_creator, created_at, id) FROM stdin;
Este es un review de ejemplo para el profesor	5	4	4.8	t	7ec2330e-7269-49d3-9075-c0d5bd1fde43	fe8d6bf8-42c4-41f5-9530-a7aa51a65714	5d8e959d-1bf0-484b-89fc-11370407a210	dc7a2fdc-b694-4168-ad8d-50a8a27ab332	2024-03-03 15:25:17.227616-05	0a21a69c-549c-4d0b-90a7-99cdfe8d4559
Este es otro review de ejemplo	5	3	5	t	e22c3fea-3a32-4b49-98fc-9047026f1e10	06ef6ca5-3bc3-4a06-8706-f181ad96ea14	5d8e959d-1bf0-484b-89fc-11370407a210	dc7a2fdc-b694-4168-ad8d-50a8a27ab332	2024-03-03 15:25:54.991888-05	aa45ab22-345a-4ea7-96e3-4be55819fb2a
Es una excelente profesora	5	2	5	t	e22c3fea-3a32-4b49-98fc-9047026f1e10	06ef6ca5-3bc3-4a06-8706-f181ad96ea14	5d8e959d-1bf0-484b-89fc-11370407a210	dc7a2fdc-b694-4168-ad8d-50a8a27ab332	2024-03-03 16:28:23.779197-05	23462504-c971-49fd-80d6-7b9b2abd31af
Muy buen profe, lo quiero mucho	5.0	4.0	5.0	t	7ec2330e-7269-49d3-9075-c0d5bd1fde43	06ef6ca5-3bc3-4a06-8706-f181ad96ea14	5d8e959d-1bf0-484b-89fc-11370407a210	dc7a2fdc-b694-4168-ad8d-50a8a27ab332	2024-03-03 20:57:20.511048-05	add6f09e-3d05-42ab-8e01-c9a8317f3d5d
Mas o menos, pudo ser mejor	3.0	3.0	3.0	f	7ec2330e-7269-49d3-9075-c0d5bd1fde43	fe8d6bf8-42c4-41f5-9530-a7aa51a65714	5d8e959d-1bf0-484b-89fc-11370407a210	dc7a2fdc-b694-4168-ad8d-50a8a27ab332	2024-03-03 21:01:29.700459-05	2e8ad0c0-fa92-491e-8ece-e0598532ed74
Excelente profesor	5.0	5.0	4.38	t	7ec2330e-7269-49d3-9075-c0d5bd1fde43	fe8d6bf8-42c4-41f5-9530-a7aa51a65714	5d8e959d-1bf0-484b-89fc-11370407a210	dc7a2fdc-b694-4168-ad8d-50a8a27ab332	2024-03-03 21:03:06.69793-05	fbead65b-dd7a-4529-8fc9-491a437e06ef
Excelente profesor!!! Lo amo	5.0	5.0	5.0	t	7ec2330e-7269-49d3-9075-c0d5bd1fde43	06ef6ca5-3bc3-4a06-8706-f181ad96ea14	5d8e959d-1bf0-484b-89fc-11370407a210	dc7a2fdc-b694-4168-ad8d-50a8a27ab332	2024-03-03 21:04:37.370893-05	4e6b9991-8971-4d70-a83f-e68c19f08460
Excelente profesor!!! Lo amo <3 uwu	5.0	5.0	4.75	t	7ec2330e-7269-49d3-9075-c0d5bd1fde43	fe8d6bf8-42c4-41f5-9530-a7aa51a65714	5d8e959d-1bf0-484b-89fc-11370407a210	dc7a2fdc-b694-4168-ad8d-50a8a27ab332	2024-03-03 21:05:52.23776-05	86018e3e-a738-4617-b119-87b7403b8454
Muy buena profesora	5.0	4.0	5.0	t	e22c3fea-3a32-4b49-98fc-9047026f1e10	06ef6ca5-3bc3-4a06-8706-f181ad96ea14	5d8e959d-1bf0-484b-89fc-11370407a210	dc7a2fdc-b694-4168-ad8d-50a8a27ab332	2024-03-03 21:08:03.666657-05	b070dab7-f3f1-493d-a347-5c6e334aa2b5
Excelente. La mejor del mundo mundial	5.0	5.0	5.0	t	e22c3fea-3a32-4b49-98fc-9047026f1e10	06ef6ca5-3bc3-4a06-8706-f181ad96ea14	5d8e959d-1bf0-484b-89fc-11370407a210	dc7a2fdc-b694-4168-ad8d-50a8a27ab332	2024-03-03 21:29:27.180763-05	54396583-144b-4bb5-bafe-577609df5066
Excelente. La mejor del mundo mundial	5.0	5.0	5.0	t	e22c3fea-3a32-4b49-98fc-9047026f1e10	06ef6ca5-3bc3-4a06-8706-f181ad96ea14	5d8e959d-1bf0-484b-89fc-11370407a210	dc7a2fdc-b694-4168-ad8d-50a8a27ab332	2024-03-03 21:30:55.683106-05	16358f39-4aeb-4823-b627-a4922b474ce0
La mejorrrrrr	5.0	5.0	5.0	t	e22c3fea-3a32-4b49-98fc-9047026f1e10	06ef6ca5-3bc3-4a06-8706-f181ad96ea14	5d8e959d-1bf0-484b-89fc-11370407a210	dc7a2fdc-b694-4168-ad8d-50a8a27ab332	2024-03-03 21:33:15.502336-05	0baac1c4-acfa-4e34-bad3-fa8d5dfe42db
La mejorrrrrr	5.0	5.0	5.0	t	e22c3fea-3a32-4b49-98fc-9047026f1e10	06ef6ca5-3bc3-4a06-8706-f181ad96ea14	5d8e959d-1bf0-484b-89fc-11370407a210	dc7a2fdc-b694-4168-ad8d-50a8a27ab332	2024-03-03 21:33:37.263173-05	b04daba3-4ab9-42cf-8141-b49368c3024c
La mejorrrrrr	5.0	5.0	5.0	t	e22c3fea-3a32-4b49-98fc-9047026f1e10	06ef6ca5-3bc3-4a06-8706-f181ad96ea14	5d8e959d-1bf0-484b-89fc-11370407a210	dc7a2fdc-b694-4168-ad8d-50a8a27ab332	2024-03-03 21:33:41.099119-05	0be8a712-f2cb-48d9-aedc-92c770c2a6a7
Neh, no gustó	3.0	2.0	2.5	f	7ec2330e-7269-49d3-9075-c0d5bd1fde43	fe8d6bf8-42c4-41f5-9530-a7aa51a65714	5d8e959d-1bf0-484b-89fc-11370407a210	dc7a2fdc-b694-4168-ad8d-50a8a27ab332	2024-03-03 21:35:49.324327-05	aa03a3a7-fc88-4d6f-9eff-0957c7231187
No muy bien	1.0	1.0	3.0	f	e22c3fea-3a32-4b49-98fc-9047026f1e10	06ef6ca5-3bc3-4a06-8706-f181ad96ea14	5d8e959d-1bf0-484b-89fc-11370407a210	dc7a2fdc-b694-4168-ad8d-50a8a27ab332	2024-03-03 21:46:46.130416-05	bb068c6f-1b18-4253-acad-3e8f694f9ffb
\.


--
-- Data for Name: student; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.student (name, nickname, email, password, fk_university, created_at, id) FROM stdin;
Nicolás Carvajal	Nico	n.carvajalc@uniandes.edu.co	1234	0c79eea7-b529-4881-8532-128081bf2a50	2024-03-03 15:22:24.317672-05	dc7a2fdc-b694-4168-ad8d-50a8a27ab332
\.


--
-- Data for Name: university; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.university (name, nickname, created_at, id) FROM stdin;
Universidad de los Andes	Uniandes	2024-03-03 15:22:03.481894-05	0c79eea7-b529-4881-8532-128081bf2a50
\.


--
-- Name: academic_period_course academic_period_course_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.academic_period_course
    ADD CONSTRAINT academic_period_course_pkey PRIMARY KEY (id);


--
-- Name: academic_period academic_period_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.academic_period
    ADD CONSTRAINT academic_period_pkey PRIMARY KEY (id);


--
-- Name: course course_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.course
    ADD CONSTRAINT course_pkey PRIMARY KEY (id);


--
-- Name: dependency dependency_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dependency
    ADD CONSTRAINT dependency_pkey PRIMARY KEY (id);


--
-- Name: professor_dependency professor_dependency_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.professor_dependency
    ADD CONSTRAINT professor_dependency_pkey PRIMARY KEY (fk_professor, fk_dependency, id);


--
-- Name: professor professor_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.professor
    ADD CONSTRAINT professor_pkey PRIMARY KEY (id);


--
-- Name: review review_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.review
    ADD CONSTRAINT review_pkey PRIMARY KEY (id);


--
-- Name: student student_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student
    ADD CONSTRAINT student_email_key UNIQUE (email);


--
-- Name: student student_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student
    ADD CONSTRAINT student_pkey PRIMARY KEY (id);


--
-- Name: university university_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.university
    ADD CONSTRAINT university_name_key UNIQUE (name);


--
-- Name: university university_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.university
    ADD CONSTRAINT university_pkey PRIMARY KEY (id);


--
-- Name: academic_period_course academic_period_course_fk_academic_period_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.academic_period_course
    ADD CONSTRAINT academic_period_course_fk_academic_period_fkey FOREIGN KEY (fk_academic_period) REFERENCES public.academic_period(id);


--
-- Name: academic_period_course academic_period_course_fk_course_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.academic_period_course
    ADD CONSTRAINT academic_period_course_fk_course_fkey FOREIGN KEY (fk_course) REFERENCES public.course(id);


--
-- Name: course course_fk_dependency_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.course
    ADD CONSTRAINT course_fk_dependency_fkey FOREIGN KEY (fk_dependency) REFERENCES public.dependency(id);


--
-- Name: dependency dependency_fk_university_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dependency
    ADD CONSTRAINT dependency_fk_university_fkey FOREIGN KEY (fk_university) REFERENCES public.university(id);


--
-- Name: professor_dependency professor_dependency_fk_dependency_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.professor_dependency
    ADD CONSTRAINT professor_dependency_fk_dependency_fkey FOREIGN KEY (fk_dependency) REFERENCES public.dependency(id);


--
-- Name: professor_dependency professor_dependency_fk_professor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.professor_dependency
    ADD CONSTRAINT professor_dependency_fk_professor_fkey FOREIGN KEY (fk_professor) REFERENCES public.professor(id);


--
-- Name: review review_fk_academic_period_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.review
    ADD CONSTRAINT review_fk_academic_period_fkey FOREIGN KEY (fk_academic_period) REFERENCES public.academic_period(id);


--
-- Name: review review_fk_course_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.review
    ADD CONSTRAINT review_fk_course_fkey FOREIGN KEY (fk_course) REFERENCES public.course(id);


--
-- Name: review review_fk_creator_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.review
    ADD CONSTRAINT review_fk_creator_fkey FOREIGN KEY (fk_creator) REFERENCES public.student(id);


--
-- Name: review review_fk_professor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.review
    ADD CONSTRAINT review_fk_professor_fkey FOREIGN KEY (fk_professor) REFERENCES public.professor(id);


--
-- Name: student student_fk_university_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.student
    ADD CONSTRAINT student_fk_university_fkey FOREIGN KEY (fk_university) REFERENCES public.university(id);


--
-- PostgreSQL database dump complete
--

